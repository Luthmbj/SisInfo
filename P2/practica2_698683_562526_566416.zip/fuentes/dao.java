import java.sql.*;
import javax.sql.*;
import com.mysql.jdbc.Driver;



public class User {

    private String nombre;
    private String apellidos;
    private String pass;
    private String fnacimiento;

    public User() {

    }

    public User(String nombre, String apellidos, String pass, String fnacimiento) {

        this.nombre = nombre;
        this.apellidos = apellidos;
        this.pass = pass;
        this.fnacimiento = fnacimiento;
    }


    public String getfecha() {
        return fnacimiento;
    }

    public void setfecha(String fnacimiento) {
        this.fnacimiento = fnacimiento;
    }

    public String getnombre() {
        return nombre;
    }

    public void setnombre(String nombre) {
        this.nombre = nombre;
    }

    public String getapellidos() {
        return apellidos;
    }

    public void setapellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getpass() {
        return pass;
    }

    public void setpass(String pass) {
        this.pass = pass;
    }
}

public class Busqueda {

    private String lugar;
    private String finicio;
    private String ffin;

    public Busqueda(){

    }
    public Busqueda(String lugar, String finicio, String ffin){
        this.lugar = lugar;
        this.finicio = finicio;
        this.ffin = ffin;
    }


    public String getlugar() {
        return lugar;
    }

    public void setlugar(String lugar) {
        this.lugar = lugar;
    }

    public String getfinicio() {
        return finicio;
    }

    public void setfinicio(String finicio) {
        this.finicio = finicio;
    }

    public String getffin() {
        return ffin;
    }

    public void setffin(String ffin) {
        this.ffin = ffin;
    }
}

public class BVuelo {

    private String destino;
    private String tipo;

    public BVuelo(){

    }
    public BVuelo(String destino, String tipo){
        this.destino = destino;
        this.tipo = tipo;
    }

    public String getdestino() {
        return destino;
    }

    public void setdestino(String destino) {
        this.destino = destino;
    }

    public String gettipo() {
        return tipo;
    }

    public void settipo(String tipo) {
        this.tipo = tipo;
    }
}

public class BCoche {

    public BCoche(){
    }
}

public class BHotel {

    private Int nhabitaciones;
    private Int npersonas;

    public BHotel(){

    }
    public BHotel(Int nhabitaciones, Int npersonas){
        this.nhabitaciones = nhabitaciones;
        this.npersonas = npersonas;
    }

    public Int getnhabitaciones() {
        return nhabitaciones;
    }

    public void setnhabitaciones(Int nhabitaciones) {
        this.nhabitaciones = nhabitaciones;
    }

    public Int getnpersonas() {
        return npersonas;
    }

    public void setnpersonas(Int npersonas) {
        this.npersonas = npersonas;
    }
}

public class Vuelo {

    private String url;
    private String nombre;

    public Vuelo(){

    }
    public Vuelo(String url, String nombre){
        this.url = url;
        this.nombre = nombre;
    }

    public String geturl() {
        return url;
    }

    public void seturl(String url) {
        this.url = url;
    }

    public String getnombre() {
        return nombre;
    }

    public void setnombre(String nombre) {
        this.nombre = nombre;
    }
}

public class Coche {

    private String url;
    private String nombre;

    public Coche(){

    }
    public Coche(String url, String nombre){
        this.url = url;
        this.nombre = nombre;
    }

    public String geturl() {
        return url;
    }

    public void seturl(String url) {
        this.url = url;
    }

    public String getnombre() {
        return nombre;
    }

    public void setnombre(String nombre) {
        this.nombre = nombre;
    }
}

public class Hotel {

    private String url;
    private String nombre;

    public Hotel(){

    }
    public Hotel(String url, String nombre){
        this.url = url;
        this.nombre = nombre;
    }

    public String geturl() {
        return url;
    }

    public void seturl(String url) {
        this.url = url;
    }

    public String getnombre() {
        return nombre;
    }

    public void setnombre(String nombre) {
        this.nombre = nombre;
    }
}


//---------------------------------------------


public interface UserDao {

    User getUser();
    User getUserByUserNameAndPassword();

    boolean insertUser();
    boolean deleteUser();

    private User extractUserFromResultSet(ResultSet rs) throws SQLException {
    User user = new User();
    user.setnombre( rs.getInt("nombre") );
    user.setapellidos( rs.getString("apellidos") );
    user.setpass( rs.getString("pass") );
    user.setfecha( rs.getInt("fnacimiento") );
    return user;
    }

    public User getUser(int id) {
    Connection connection = connectionFactory.getConnection();
    try {
        Statement stmt = connection.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT * FROM usuario WHERE nombre=" + nombre " and apellidos=" + apellidos);
        if(rs.next()){
            return extractUserFromResultSet(rs);
        }
    } catch (SQLException ex) {
        ex.printStackTrace();
    }
        return null;
    }

    public User getUserByUserNameAndPassword(String nombre, String apellidos, String pass) {
    Connector connector = new Connector();
    Connection connection = connector.getConnection();
    try {
        PreparedStatement ps = connection.prepareStatement("SELECT * FROM usuario WHERE nombre=? AND apellidos=? AND pass=?");
        ps.setString(1, nombre);
        ps.setString(2, apellidos);
        ps.setString(3, pass);
        ResultSet rs = ps.executeQuery();
        if(rs.next())
        {
    return extractUserFromResultSet(rs);
        }
    } catch (SQLException ex) {
        ex.printStackTrace();
    }
    return null;
    }

    public boolean insertUser(User user) {
    Connector connector = new Connector();
    Connection connection = connector.getConnection();
    try {
        PreparedStatement ps = connection.prepareStatement("INSERT INTO usuario VALUES (?, ?, ?, ?)");
        ps.setString(1, user.getnombre());
        ps.setString(2, user.getapellidos());
        ps.setString(3, user.getfecha());
        ps.setString(4, user.getpass());
        int i = ps.executeUpdate();
      if(i == 1) {
        return true;
      }
    } catch (SQLException ex) {
        ex.printStackTrace();
    }
    return false;
    }

    public boolean deleteUser(int id) {
    Connector connector = new Connector();
    Connection connection = connector.getConnection();
    try {
    Statement stmt = connection.createStatement();
    int i = stmt.executeUpdate("DELETE FROM usuario WHERE nombre=" + nombre " and apellidos=" + apellidos);
    if(i == 1) {
    return true;
      }
    } catch (SQLException ex) {
        ex.printStackTrace();
    }
    return false;
    }


}
------------
