package ejemplo;

import java.sql.*;
import java.util.ArrayList;

public class Comparacion {

	public static void insertUser(UserVO user) throws InstantiationException, IllegalAccessException, ClassNotFoundException{
		Connection c;
		Statement s;
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver").newInstance();
		}
		catch(Exception e){}
		try{
			Driver myDriver=new oracle.jdbc.driver.OracleDriver();
			DriverManager.registerDriver(myDriver);
			c=DriverManager.getConnection("jdbc:oracle:thin:@hendrix-oracle.cps.unizar.es:1521:vicious", "a679513", "Thunde25");
			s=c.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
	                 ResultSet.CONCUR_UPDATABLE);
			if(!user.getfechaNac().equals("Dia/Mes/Anio")){
				s.execute("INSERT INTO Usuarios(idUsuario,nombre,apellidos,correo,fechaNac,clave) VALUES (6,'"
						+user.getNombre()+"','"+user.getApellido()+"','"+user.getCorreo()+"','"+user.getfechaNac()+"','"+user.getClave()+"')");
			}
			else{
				s.execute("INSERT INTO Usuarios(idUsuario,nombre,apellidos,correo,fechaNac,clave) VALUES (6,'"
						+user.getNombre()+"','"+user.getApellido()+"','"+user.getCorreo()+"',"+null+",'"+user.getClave()+"')");
			}
		}
		catch (Exception e){ e.printStackTrace();}
	}
	public static void insertContacto(String nombre, String email, String password) throws InstantiationException, IllegalAccessException, ClassNotFoundException{
		

	}
	public static String findUser(String email, String password) throws InstantiationException, IllegalAccessException, ClassNotFoundException{
		ResultSet res;
		Connection c=null;
		Statement stmt;
		String name="";
		try {
			   Class.forName("oracle.jdbc.driver.OracleDriver").newInstance();
			}
			catch(ClassNotFoundException ex) {}
			catch(IllegalAccessException ex) {}
			catch(InstantiationException ex) {
			}
		try {
			Driver myDriver = new oracle.jdbc.driver.OracleDriver();
			DriverManager.registerDriver( myDriver );
			c=DriverManager.getConnection("jdbc:oracle:thin:@hendrix-oracle.cps.unizar.es:1521:vicious","a679513","Thunde25");
         stmt=c.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
                 ResultSet.CONCUR_UPDATABLE);
			//res = stmt.executeQuery("SELECT * FROM alojamiento WHERE Ciudad='%"+ciudad+"%' and tipo='%"+opcion+"%' ORDER BY '%"+orden+"%'");
			res=stmt.executeQuery("select nombre from usuarios where correo='"+email+"' and clave='"+password+"'");
			while(res.next()){
				name=res.getString("Nombre");
			}
		
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
		}
		return name;
	}
	public static void deleteUser(String email, String password) throws InstantiationException, IllegalAccessException, ClassNotFoundException{
		Connection c;
		Statement s;
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver").newInstance();
		}
		catch(Exception e){}
		try{
			Driver myDriver=new oracle.jdbc.driver.OracleDriver();
			DriverManager.registerDriver(myDriver);
			c=DriverManager.getConnection("jdbc:oracle:thin:@hendrix-oracle.cps.unizar.es:1521:vicious", "a679513", "Thunde25");
			s=c.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
	                 ResultSet.CONCUR_UPDATABLE);
			s.execute("delete from usuarios where correo='"+email+"' and clave='"+password+"'");
		}
		catch (Exception e){ e.printStackTrace();}

	}
	public static void findHoteles(String opciones, String ciudad) throws InstantiationException, IllegalAccessException, ClassNotFoundException{
		

	}
	public static ArrayList<ArrayList<String>> HFotos(String[] lista){
		Connection c;
		Statement s;
		ArrayList<ArrayList<String>> info=new ArrayList<ArrayList<String>>();
		ArrayList<String> hotel;
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver").newInstance();
		}
		catch(Exception e){}
		try{
			Driver myDriver=new oracle.jdbc.driver.OracleDriver();
			DriverManager.registerDriver(myDriver);
			c=DriverManager.getConnection("jdbc:oracle:thin:@hendrix-oracle.cps.unizar.es:1521:vicious", "a679513", "Thunde25");
			s=c.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
	                 ResultSet.CONCUR_UPDATABLE);
			ResultSet res,res2;
			for(int i=0;i<lista.length;i++){
				if(lista[i]!=null){
					hotel=new ArrayList<String>();
					res=s.executeQuery("select fotoini,direccion,AVGValoracion,aparcamiento,ascensor, bar,cajafuerte,gimnasio,peluqueria,recepcion24h,restaurante from alojamiento,servicios"
							+ " where id like '%"+lista[i]+"%' and id=hotel");
					while(res.next()){
						//res2=s.executeQuery("select puntuacion from opinion where producto='"+Integer.parseInt(res.getString("id"))+"'");
						//insert into servicios(hotel,aparcamiento,ascensor, bar,cajafuerte,gimnasio,peluqueria,recepcion24h,restaurante) values ('Ibis Budget2 Zaragoza','S','N','S','S','N','S','N','S');
						hotel.add(lista[i]);
						hotel.add(res.getString("fotoini"));
						hotel.add(res.getString("direccion"));
						hotel.add(res.getString("AVGValoracion"));
						hotel.add(res.getString("aparcamiento"));
						hotel.add(res.getString("ascensor"));
						hotel.add(res.getString("bar"));
						hotel.add(res.getString("cajafuerte"));
						hotel.add(res.getString("gimnasio"));
						hotel.add(res.getString("peluqueria"));
						hotel.add(res.getString("recepcion24h"));
						hotel.add(res.getString("restaurante"));
					}
					info.add(hotel);
				}	
			}
			
		}
		catch (Exception e){ e.printStackTrace();}
		return info;
	}
	public static ArrayList<ArrayList<String>> HPrecios(String[] lista){
		Connection c;
		Statement s;
		ArrayList<ArrayList<String>> info=new ArrayList<ArrayList<String>>();
		ArrayList<String> hotel;
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver").newInstance();
		}
		catch(Exception e){}
		try{
			Driver myDriver=new oracle.jdbc.driver.OracleDriver();
			DriverManager.registerDriver(myDriver);
			c=DriverManager.getConnection("jdbc:oracle:thin:@hendrix-oracle.cps.unizar.es:1521:vicious", "a679513", "Thunde25");
			s=c.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
	                 ResultSet.CONCUR_UPDATABLE);
			ResultSet res;
			for(int i=0;i<lista.length;i++){
				if(lista[i]!=null){
					hotel=new ArrayList<String>();
					res=s.executeQuery("select producto,cantidad,nombre from precios,webreserva"
							+ " where URL=precios.web and producto like '%"+lista[i]+"%'"
							+ " order by cantidad asc");
					while(res.next()){
						hotel.add(res.getString("cantidad"));
						hotel.add(res.getString("nombre"));
					}
					info.add(hotel);	
				}
				
			}
			
		}
		catch (Exception e){ e.printStackTrace();}
		return info;
	}
	public static ArrayList<Integer> HOpiniones(String[] lista){
		Connection c;
		Statement s;
		ArrayList<Integer> info = null;
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver").newInstance();
		}
		catch(Exception e){}
		try{
			Driver myDriver=new oracle.jdbc.driver.OracleDriver();
			DriverManager.registerDriver(myDriver);
			c=DriverManager.getConnection("jdbc:oracle:thin:@hendrix-oracle.cps.unizar.es:1521:vicious", "a679513", "Thunde25");
			s=c.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
	                 ResultSet.CONCUR_UPDATABLE);
			ResultSet res;
			for(int i=0;i<lista.length;i++){
				res=s.executeQuery("select puntuacion from opinion"
						+ " where id like '&"+lista[i]+"'");
				int suma=0;
				while(res.next()){
					suma=suma +(Integer.parseInt(res.getString("puntucion")));
				}
				
				info.add(suma);	
			}
			
		}
		catch (Exception e){ e.printStackTrace();}
		return info;
	}
}
