package ejemplo;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class ServletInicio extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public void init(ServletConfig conf)
		    throws ServletException {
		    super.init(conf);
		  }
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException{
		doPost(request,response);
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		
	    
		Map<String, String> errors= new HashMap<String, String>();
		
		String recordar=request.getParameter("recuerdo");
		System.out.println(recordar);
		String email = request.getParameter("mail");
		String password = request.getParameter("contrasena");
		if (email.length()==0) errors.put("errorCorreo", "Campo Obligatorio");
		if (password.length()==0) errors.put("errorPass", "Campo Obligatorio");
		if(errors.isEmpty()){

			try {
				String n=ModelFacade.findUser(email,password);
				if (n.length()==0){
					errors.put("errorUsuario", "El correo o la contrasena son incorrectas");
					request.setAttribute("errors", errors);
					RequestDispatcher requestDispatcher =
					request.getRequestDispatcher("InicioSesion.jsp");
					requestDispatcher.forward(request, response);
				}
				else{
					if(recordar!=null){
						Cookie c=new Cookie("correo",email);
						response.addCookie(c);
			    	}else{
			    		Cookie cookie = new Cookie("correo", "");
						cookie.setMaxAge(0); 

						response.addCookie(cookie);
			    	}
					HttpSession actual=request.getSession(true);
					actual.setAttribute("logeado",email);
					RequestDispatcher requestDispatcher =
					request.getRequestDispatcher("PaginaUsuario.jsp");
					requestDispatcher.forward(request, response);
				}
				

			} catch (InstantiationException | IllegalAccessException | ClassNotFoundException e) {
				PrintWriter out=response.getWriter();
				out.println("Si estas viendo este mensaje es por que algo salio mal, no se pudo completar tu solicitud.");
				e.printStackTrace();
			}
			
		}
		else{
			request.setAttribute("errors", errors);
			RequestDispatcher requestDispatcher =
			request.getRequestDispatcher("InicioSesion.jsp");
			requestDispatcher.forward(request, response);
		}
		
	}

}
