package ejemplo;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ServletDarDeBaja extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public void init(ServletConfig conf)
		    throws ServletException {
		    super.init(conf);
		  }
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException{
		doPost(request,response);
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		
	    
		Map<String, String> errors= new HashMap<String, String>();
		
		String email = request.getParameter("mail");
		String password = request.getParameter("contrasena");
		String motivos =request.getParameter("Motivos");
		String mejoras =request.getParameter("Mejoras");
		if (email.length()==0) errors.put("errorEmail", "Campo Obligatorio");
		if (password.length()==0) errors.put("errorNoPass", "Campo Obligatorio");
		if(errors.isEmpty()){

			try {
				ModelFacade.deleteUser(email,password,motivos,mejoras);
				response.setContentType("text/html; charset=ISO-8859-1");
				PrintWriter out = response.getWriter();
				out.println("<html><head><title>Baja usuario</title></head>");
				out.println("<body><p> El usuario con email " + email
				+ " ha sido dado de baja correctamente </p>");
				out.println("</body></html>");
				out.println("<a href=index.jsp>Volver inicio</a>");

			} catch (InstantiationException | IllegalAccessException | ClassNotFoundException e) {
				PrintWriter out=response.getWriter();
				out.println("Si estas viendo este mensaje es por que algo salio mal, no se pudo completar tu solicitud.");
				e.printStackTrace();
			}
			
		}
		else{
			request.setAttribute("errors", errors);
			RequestDispatcher requestDispatcher =
			request.getRequestDispatcher("DarDeBaja.jsp");
			requestDispatcher.forward(request, response);
		}
		
	}

}
