package ejemplo;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class ServletReserva extends HttpServlet{

	public void init(ServletConfig conf)
		    throws ServletException {
		    super.init(conf);
		  }
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException{
		doPost(request,response);
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		try{
			String alojamiento = request.getParameter("alojamiento");
			String url= request.getParameter("url");
			String cantidad=request.getParameter("cantidad");
			HttpSession actual=request.getSession(true);
			String nombre=(String)actual.getAttribute("logeado");
			if(nombre!=null){
				ModelFacade.insertReserva(url, alojamiento, nombre, Integer.parseInt(cantidad));
			}
			RequestDispatcher requestDispatcher =
			request.getRequestDispatcher(url);
			requestDispatcher.forward(request, response);
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}

}
