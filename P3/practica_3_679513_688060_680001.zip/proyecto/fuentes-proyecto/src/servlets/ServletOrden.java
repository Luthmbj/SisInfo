package ejemplo;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ServletOrden extends HttpServlet{

	public void init(ServletConfig conf)
		    throws ServletException {
		    super.init(conf);
		  }
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException{
		doPost(request,response);
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		
		String opciones = request.getParameter("Opciones");
		String ciudad = request.getParameter("Ciudad");
		if (ciudad.length()==0) ciudad="Zaragoza";
		String orden = request.getParameter("Ordenar");
		request.setAttribute("tipo",opciones);
		request.setAttribute("ciudad", ciudad);
		request.setAttribute("orden", orden);
		RequestDispatcher requestDispatcher =
		request.getRequestDispatcher("listado.jsp");
		requestDispatcher.forward(request, response);
		
	}

}
