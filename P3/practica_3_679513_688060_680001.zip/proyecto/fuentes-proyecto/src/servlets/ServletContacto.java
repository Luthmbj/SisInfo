package ejemplo;


import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ServletContacto extends HttpServlet{

	public void init(ServletConfig conf)
		    throws ServletException {
		    super.init(conf);
		  }
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException{
		doPost(request,response);
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		
	    
		Map<String, String> errors= new HashMap<String, String>();
		
		String nombre = request.getParameter("nombre");
		String apellidos=request.getParameter("apellidos");
		String email = request.getParameter("email");
		String reemail = request.getParameter("reemail");
		String mensaje = request.getParameter("Mensaje");
		if (nombre.length()==0) errors.put("errorNombre", "Campo Obligatorio");
		if (apellidos.length()==0) errors.put("errorApellidos", "Campo Obligatorio");
		if (email.length()==0) errors.put("errorEmail", "Campo Obligatorio");
		if (reemail.length()==0) errors.put("errorReEmail", "Campo Obligatorio");
		if (!reemail.equals(email)) errors.put("errorNoCoincide", "Campo Obligatorio");
		if (mensaje.length()==0) errors.put("errorMens", "Campo Obligatorio");
		if(errors.isEmpty()){

			try {
				ModelFacade.insertContacto(nombre,apellidos,email,mensaje);
				response.setContentType("text/html; charset=ISO-8859-1");
				PrintWriter out = response.getWriter();
				out.println("<html><head><title>Formulario de contacto</title></head>");
				out.println("<body><p> El usuario con nombre " + nombre
				+ " ha enviado su mensaje correctamente. </p>");
				out.println("</body></html>");
				out.println("<a href=index.jsp>Volver inicio</a>");

			} catch (InstantiationException | IllegalAccessException | ClassNotFoundException e) {
				PrintWriter out=response.getWriter();
				out.println("Si estas viendo este mensaje es por que algo salio mal, no se pudo completar tu solicitud.");
				e.printStackTrace();
			}
			
		}
		else{
			request.setAttribute("errors", errors);
			RequestDispatcher requestDispatcher =
			request.getRequestDispatcher("FormularioContacto.jsp");
			requestDispatcher.forward(request, response);
		}
		
	}

}
