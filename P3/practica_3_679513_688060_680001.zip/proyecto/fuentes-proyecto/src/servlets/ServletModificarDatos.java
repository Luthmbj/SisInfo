package ejemplo;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class ServletModificarDatos extends HttpServlet{
	
	public void init(ServletConfig conf)
		    throws ServletException {
		    super.init(conf);
		  }
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException{
		doPost(request,response);
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		
	    
		Map<String, String> errors= new HashMap<String, String>();
		
		String name = request.getParameter("nombre");
		String surname = request.getParameter("apellidos"); 
		String dia=request.getParameter("Dia");
		String mes=request.getParameter("Mes");
		String ano=request.getParameter("Ano");
		String email = request.getParameter("mail");
		String password = request.getParameter("contrasena");
		String repassword = request.getParameter("repcont"); 
		if (name.length()==0) errors.put("errorNombre", "Campo Obligatorio");
		if (surname.length()==0) errors.put("errorApellido", "Campo Obligatorio");
		if (email.length()==0) errors.put("errorCorreo", "Campo Obligatorio");
		if (password.length()==0) errors.put("errorPass", "Campo Obligatorio");
		if (repassword.length()==0) errors.put("errorRePass", "Campo Obligatorio");
		if (password.compareTo(repassword)!=0) errors.put("errorDist", "Las contrasenas no coinciden");
		if(errors.isEmpty()){	
			UserVO user = new UserVO(name, surname, email,dia+"/"+mes+"/"+ano,password);
			try {
				ModelFacade.modificarUser(user);
				PrintWriter out = response.getWriter();
				out.println("<script type=\"text/javascript\">");
				out.println("alert('Modificación de datos correcta');");
				out.println("location='PaginaUsuario.jsp';");
				out.println("</script>");
				RequestDispatcher requestDispatcher =
				request.getRequestDispatcher("PaginaUsuario.jsp");
				requestDispatcher.forward(request, response);
				response.setContentType("text/html; charset=ISO-8859-1");
				
				
			} catch (InstantiationException | IllegalAccessException | ClassNotFoundException e) {
				PrintWriter out=response.getWriter();
				out.println("Si estas viendo este mensaje es por que algo salio mal, no se pudo completar tu solicitud.");
				e.printStackTrace();
			}
		}
		else{
			request.setAttribute("errors", errors);
			RequestDispatcher requestDispatcher =
			request.getRequestDispatcher("Registro.jsp");
			requestDispatcher.forward(request, response);
		}
		
	}
	
	
}
