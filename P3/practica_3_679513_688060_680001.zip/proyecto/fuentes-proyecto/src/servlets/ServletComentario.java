package ejemplo;


import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class ServletComentario extends HttpServlet{

	public void init(ServletConfig conf)
		    throws ServletException {
		    super.init(conf);
		  }
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException{
		doPost(request,response);
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		
	    
		
		HttpSession actual=request.getSession(true);
		String nombre=(String)actual.getAttribute("logeado");
		String puntuacion=request.getParameter("puntuacion");
		String mensaje = request.getParameter("Mensaje");
		String producto=request.getParameter("alojamiento");
			try {
				ModelFacade.insertComentario(nombre,producto,puntuacion,mensaje);
				RequestDispatcher requestDispatcher =
				request.getRequestDispatcher("PaginaUsuario.jsp");
				requestDispatcher.forward(request, response);

			} catch (InstantiationException | IllegalAccessException | ClassNotFoundException e) {
				PrintWriter out=response.getWriter();
				out.println("Si estas viendo este mensaje es por que algo salio mal, no se pudo completar tu solicitud.");
				e.printStackTrace();
			}

		
	}

}
