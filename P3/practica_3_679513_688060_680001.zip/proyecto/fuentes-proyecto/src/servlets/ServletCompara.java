package ejemplo;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ServletCompara extends HttpServlet{
	
	public void init(ServletConfig conf)
		    throws ServletException {
		    super.init(conf);
		  }
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException{
		doPost(request,response);
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		
		String[] s=request.getParameterValues("hotel");
		ArrayList<ArrayList<String>> a=Comparacion.HFotos(s);
		request.setAttribute("fotos", a);
		ArrayList<ArrayList<String>> p=Comparacion.HPrecios(s);
		request.setAttribute("precios", p);
		RequestDispatcher requestDispatcher =
				request.getRequestDispatcher("Comparar.jsp");
				requestDispatcher.forward(request, response);
		//insert into webreserva(url,nombre) values ('http://alo.com','alo');
				//insert into coste(producto,web) values ('Ibis Budget Zaragoza','http://hola.com');
				//insert into precios(producto,cantidad,web) values ('Ibis Budget2 Zaragoza',60,'http://hola.com');
	}

}
