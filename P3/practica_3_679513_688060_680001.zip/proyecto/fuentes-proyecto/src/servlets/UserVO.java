package ejemplo;
public class UserVO {
	
	private String nombre;
	private String apellidos;
	private String correo;
	private String fechaNac;
	private String clave;

	public UserVO(String nombre, String apellidos,String correo,String FechaNac,String clave){
		this.nombre=nombre;
		this.apellidos=apellidos;
		this.correo=correo;
		this.fechaNac=FechaNac;
		this.clave=clave;
	}
	public String getNombre(){
		return nombre;
	}
	public String getApellido(){
		return apellidos;
	}
	public String getCorreo(){
		return correo;
	}
	public String getfechaNac(){
		return fechaNac;
	}
	public String getClave(){
		return clave;
	}
}
