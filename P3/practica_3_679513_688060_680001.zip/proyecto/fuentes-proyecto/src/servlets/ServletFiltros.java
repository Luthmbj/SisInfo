package ejemplo;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ServletFiltros extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public void init(ServletConfig conf)
		    throws ServletException {
		    super.init(conf);
		  }
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException{
		doPost(request,response);
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		
		String opciones="";
		if(request.getParameter("Opciones").equals("Hoteles")){
			opciones="H";
		}else{
			opciones="A";
		}
		String ciudad = request.getParameter("Ciudad");
		if (ciudad.length()==0) ciudad="Zaragoza";
		String orden="";
		if(request.getParameter("Ordenar").equals("Valoraciones")){
			orden="AVGValoracion DESC";
		}else{
			orden="MejorPrecio ASC";
		}
		String estrella="0";
		switch(request.getParameter("Estrellas")){
		case "1e":
			estrella="1";
			break;
		case "2e":
			estrella="2";
			break;
		case "3e":
			estrella="3";
			break;
		case "4e":
			estrella="4";
			break;
		case "5e":
			estrella="5";
			break;
		default:
			break;
		}
		String valoracion="0";
		switch(request.getParameter("Valoracion:")){
		case "muyMal":
			valoracion="0";
			break;
		case "mal":
			valoracion="3";
			break;
		case "indiferente":
			valoracion="5";
			break;
		case "bien":
			valoracion="7";
			break;
		case "muyBien":
			valoracion="10";
			break;
		default:
			break;
		}
		String precioMin= request.getParameter("pMin");
		String precioMax= request.getParameter("pMax");
		request.setAttribute("tipo",opciones);
		request.setAttribute("ciudad", ciudad);
		request.setAttribute("orden", orden);
		request.setAttribute("start", estrella);
		request.setAttribute("val", valoracion);
		request.setAttribute("pMin", precioMin);
		request.setAttribute("pMax", precioMax);
		RequestDispatcher requestDispatcher =
		request.getRequestDispatcher("listado.jsp");
		requestDispatcher.forward(request, response);
		
	}

}
