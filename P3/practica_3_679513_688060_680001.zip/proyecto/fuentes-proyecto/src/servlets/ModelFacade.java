package ejemplo;

import java.sql.*;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Random;

public class ModelFacade {
	
	private static int i=0;
	
	public static void addI(){
		i++;
	}

	public static void insertUser(UserVO user) throws InstantiationException, IllegalAccessException, ClassNotFoundException{
		Connection c;
		Statement s;
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver").newInstance();
		}
		catch(Exception e){}
		try{
			Driver myDriver=new oracle.jdbc.driver.OracleDriver();
			DriverManager.registerDriver(myDriver);
			c=DriverManager.getConnection("jdbc:oracle:thin:@hendrix-oracle.cps.unizar.es:1521:vicious", "a679513", "Thunde25");
			s=c.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
	                 ResultSet.CONCUR_UPDATABLE);
			if(!user.getfechaNac().equals("Dia/Mes/Anio")){
				if(findUser(user.getCorreo(),user.getClave()).length()!=0){
					s.execute("INSERT INTO Usuarios(idUsuario,nombre,apellidos,correo,fechaNac,clave) VALUES ('"+user.getCorreo()+"','"
							+user.getNombre()+"','"+user.getApellido()+"','"+user.getCorreo()+"','"+user.getfechaNac()+"','"+user.getClave()+"')");
				
				}
			}
			else{
				if(findUser(user.getCorreo(),user.getClave()).length()!=0){
					s.execute("INSERT INTO Usuarios(idUsuario,nombre,apellidos,correo,fechaNac,clave) VALUES ('"+user.getCorreo()+"','"
							+user.getNombre()+"','"+user.getApellido()+"','"+user.getCorreo()+"',"+null+",'"+user.getClave()+"')");
				}
			}
		}
		catch (Exception e){ e.printStackTrace();}
	}
	public static void modificarUser(UserVO user)throws InstantiationException, IllegalAccessException, ClassNotFoundException{
		Connection c;
		Statement s;
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver").newInstance();
		}
		catch(Exception e){}
		try{
			Driver myDriver=new oracle.jdbc.driver.OracleDriver();
			DriverManager.registerDriver(myDriver);
			c=DriverManager.getConnection("jdbc:oracle:thin:@hendrix-oracle.cps.unizar.es:1521:vicious", "a679513", "Thunde25");
			s=c.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
	                 ResultSet.CONCUR_UPDATABLE);
			String u=findUser(user.getCorreo(),user.getClave());
			if(!user.getfechaNac().equals("Dia/Mes/Anio")){
				s.execute("update Usuarios set nombre='"+user.getNombre()+"',apellidos='"+user.getApellido()+"',fechaNac='"+user.getfechaNac()+"' where correo='"+u+"'");
			}
			else{
				s.execute("update Usuarios set nombre='"+user.getNombre()+"',apellidos='"+user.getApellido()+"' where correo='"+u+"'");

			}
		}
		catch (Exception e){ e.printStackTrace();}
	}
	public static void insertComentario(String email,String producto,String puntuacion,String mensaje)throws InstantiationException, IllegalAccessException, ClassNotFoundException{
		Connection c;
		Statement s;
		Random g=new Random();
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver").newInstance();
		}
		catch(Exception e){}
		try{
			Driver myDriver=new oracle.jdbc.driver.OracleDriver();
			DriverManager.registerDriver(myDriver);
			c=DriverManager.getConnection("jdbc:oracle:thin:@hendrix-oracle.cps.unizar.es:1521:vicious", "a679513", "Thunde25");
			s=c.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
	                 ResultSet.CONCUR_UPDATABLE);
			if(mensaje.length()==0){
				s.execute("INSERT INTO Opinion(idOpinion,usuario,producto,puntuacion,texto) VALUES ("+g.nextInt(1000)+",'"+email+"','"+producto+"',"+puntuacion+","+null+")");
			}
			if(mensaje.length()!=0){
				s.execute("INSERT INTO Opinion(idOpinion,usuario,producto,puntuacion,texto) VALUES ("+g.nextInt(1000)+",'"+email+"','"+producto+"',"+puntuacion+",'"+mensaje+"')");			
			}
			addI();
		}
		catch (Exception e){ e.printStackTrace();}
	}
	
	public static void insertReserva(String web,String producto,String nombre,int cantidad)throws InstantiationException, IllegalAccessException, ClassNotFoundException{
		Connection c;
		Statement s;
		Calendar c1 = new GregorianCalendar();
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver").newInstance();
		}
		catch(Exception e){}
		try{
			Driver myDriver=new oracle.jdbc.driver.OracleDriver();
			DriverManager.registerDriver(myDriver);
			c=DriverManager.getConnection("jdbc:oracle:thin:@hendrix-oracle.cps.unizar.es:1521:vicious", "a679513", "Thunde25");
			s=c.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
	                 ResultSet.CONCUR_UPDATABLE);
			s.execute("INSERT INTO hreservas(web,producto,usuario,precio,fecha) VALUES ('"+web+"','"+producto+"','"+nombre+"',"+cantidad+",'"+c1.get(Calendar.DATE)+"/"+c1.get(Calendar.MONTH)+"/"+c1.get(Calendar.YEAR)+"-"+c1.get(Calendar.HOUR)+":"+c1.get(Calendar.MINUTE)+" "+c1.get(Calendar.AM_PM)+"'");
		}catch (Exception e){ e.printStackTrace();}
		
	}
	
	public static void insertBusqueda(String nombre,String opciones,String ciudad)throws InstantiationException, IllegalAccessException, ClassNotFoundException{
		Random g=new Random();
		Connection c;
		Statement s;
		Calendar c1 = new GregorianCalendar();
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver").newInstance();
		}
		catch(Exception e){}
		try{
			Driver myDriver=new oracle.jdbc.driver.OracleDriver();
			DriverManager.registerDriver(myDriver);
			c=DriverManager.getConnection("jdbc:oracle:thin:@hendrix-oracle.cps.unizar.es:1521:vicious", "a679513", "Thunde25");
			s=c.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
	                 ResultSet.CONCUR_UPDATABLE);
			s.execute("INSERT INTO hbusqueda(usuario,ciudad,fecha,opcion) VALUES ('"+nombre+"','"+ciudad+"','"+c1.get(Calendar.DATE)+"/"+c1.get(Calendar.MONTH)+"/"+c1.get(Calendar.YEAR)+"-"+c1.get(Calendar.HOUR)+":"+c1.get(Calendar.MINUTE)+":"+c1.get(Calendar.SECOND)+" "+c1.get(Calendar.AM_PM)+"','"+opciones+"')");
		}catch (Exception e){ e.printStackTrace();}
	}

		
	public static void insertContacto(String nombre,String apellidos, String email, String mensaje) throws InstantiationException, IllegalAccessException, ClassNotFoundException{
		Connection c;
		Statement s;
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver").newInstance();
		}
		catch(Exception e){}
		try{
			Driver myDriver=new oracle.jdbc.driver.OracleDriver();
			DriverManager.registerDriver(myDriver);
			c=DriverManager.getConnection("jdbc:oracle:thin:@hendrix-oracle.cps.unizar.es:1521:vicious", "a679513", "Thunde25");
			s=c.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
	                 ResultSet.CONCUR_UPDATABLE);
			s.execute("INSERT INTO contacto(idUsuario,nombre,apellidos,correo,mensaje) VALUES ('"+email+"','"+nombre+"','"+apellidos+"','"+email+"','"+mensaje+"')");
		}
		catch (Exception e){ e.printStackTrace();}

	}
	public static String findUser(String email, String password) throws InstantiationException, IllegalAccessException, ClassNotFoundException{
		ResultSet res;
		Connection c=null;
		Statement stmt;
		String name="";
		try {
			   Class.forName("oracle.jdbc.driver.OracleDriver").newInstance();
			}
			catch(ClassNotFoundException ex) {}
			catch(IllegalAccessException ex) {}
			catch(InstantiationException ex) {
			}
		try {
			Driver myDriver = new oracle.jdbc.driver.OracleDriver();
			DriverManager.registerDriver( myDriver );
			c=DriverManager.getConnection("jdbc:oracle:thin:@hendrix-oracle.cps.unizar.es:1521:vicious","a679513","Thunde25");
         stmt=c.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
                 ResultSet.CONCUR_UPDATABLE);
			res=stmt.executeQuery("select correo from usuarios where correo='"+email+"' and clave='"+password+"'");
			while(res.next()){
				name=res.getString("Correo");
			}
		
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
		}
		return name;
	}
	public static void deleteUser(String email, String password,String motivos,String mejoras) throws InstantiationException, IllegalAccessException, ClassNotFoundException{
		Connection c;
		Statement s;
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver").newInstance();
		}
		catch(Exception e){}
		try{
			Driver myDriver=new oracle.jdbc.driver.OracleDriver();
			DriverManager.registerDriver(myDriver);
			c=DriverManager.getConnection("jdbc:oracle:thin:@hendrix-oracle.cps.unizar.es:1521:vicious", "a679513", "Thunde25");
			s=c.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
	                 ResultSet.CONCUR_UPDATABLE);
			s.execute("delete from usuarios where correo='"+email+"' and clave='"+password+"'");
		}
		catch (Exception e){ e.printStackTrace();}

	}
}
